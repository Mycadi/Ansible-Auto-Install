Resources
````````````````
Internal resources
-------------------------
- http://docs.ansible.com/
- https://sites.google.com/a/ansibleworks.com/ansible-intranet/
- ??? intranet Engineering doc???


External Resources
-------------------------
- www.apstylebook.com
- www.chicagomanualofstyle.org—home.html
- www.crockford.com—style.html
- orwell.ru—index.htm
- www.sun.com—sun_tech_pub.xml
- webopedia.internet.com
- www.computeruser.com—index.html
